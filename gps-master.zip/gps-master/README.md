# gps

Gps tracker for FiveM Modification.
ESX Not needed.

/gps <tracked location>, easy to add more if you have any know-how.

Currently
/gps 
  shop
  clothshop
  weaponshop
  barbershop
  bank
  booze
  tuning
  tattoo
  
Will give the player GPS location waypoint on map to nearest written location.
Easy to import into menu-version with little know-how if you wish, i prefer command myself.
